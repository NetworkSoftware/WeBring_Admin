package pro.network.yaluadmin.product;

public interface OnStockClick {

    void onDeleteClick(int position);

    void onEditClick(Product position);
}
