package pro.network.yaluadmin.ad;

public interface AdClick {

    void onDeleteClick(int position);
}
