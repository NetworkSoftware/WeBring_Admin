package pro.network.yaluadmin.app;

public class Appconfig {

    //Key values
    public static final String shopIdKey = "shopIdKey";
    public static final String mypreference = "mypref";

    public static final String ip = "http://thestockbazaar.com/admin/e-commerce/yalu_mobile";


    public static String URL_IMAGE_UPLOAD = ip + "/fileUpload.php";
    public static String BANNER_CREATE = ip + "/fileFeed.php";
    public static String BANNER_GET_ALL = ip + "/get_all_feed.php";
    public static String BANNER_DELETE = ip + "/fileDelete.php";

    //Stack
    public static final String PRODUCT_CREATE = ip + "/create_stock.php";
    public static final String PRODUCT_UPDATE = ip + "/update_stock.php";
    public static final String PRODUCT_GET_ALL = ip + "/dataFetchAll.php";
    public static final String PRODUCT_DELETE = ip + "/delete_stock.php";

    //Banner
    public static final String BANNERS_CREATE = ip + "/create_banner.php";
    public static final String BANNERS_UPDATE = ip + "/update_stock.php";
    public static final String BANNERS_GET_ALL = ip + "/dataFetchAll_banner.php";
    public static final String BANNERS_DELETE = ip + "/delete_banner.php";
    //Order
    public static final String ORDER_GET_ALL = ip + "/dataFetchAll_order.php";
    public static final String ORDER_CHANGE_STATUS = ip + "/order_change_status.php";


    public static final String IMAGE_URL = ip + "/images/";

    public static String getResizedImage(String path, boolean isResized) {
        if (isResized) {
            return IMAGE_URL+ "small/"+path.substring(path.lastIndexOf("/")+1);
        }
        return path;
    }
}
