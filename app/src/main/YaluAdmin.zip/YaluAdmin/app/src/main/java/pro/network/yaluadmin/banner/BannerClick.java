package pro.network.yaluadmin.banner;

public interface BannerClick {

    void onDeleteClick(int position);
}
